package com.rideSystem.Ride.POJO;

public enum OrderStatus {
    UNPAID,
    PAID,
    REFUNDING,
    REFUNDED
}

package com.rideSystem.Ride.POJO;

public enum RideStatus {
    Created,
    Received_Order,

    Departed,
    PickedUp,
    Arrived,
    Terminated
}

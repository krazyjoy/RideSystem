package com.rideSystem.Ride.POJO;

public enum RideType {
    ECONOMY,
    COMFORTABLE,
    LUXURY
}

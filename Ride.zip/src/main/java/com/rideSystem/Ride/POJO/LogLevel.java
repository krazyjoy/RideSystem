package com.rideSystem.Ride.POJO;

public enum LogLevel {
    INFO,
    DEBUG,
    WARNING,
    ERROR
}

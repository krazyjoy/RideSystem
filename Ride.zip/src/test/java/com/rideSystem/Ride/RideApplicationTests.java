package com.rideSystem.Ride;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RideApplicationTests {

	@Test
	void contextLoads() {
	}

}
